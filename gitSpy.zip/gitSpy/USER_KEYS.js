// INSERT YOUR OWN KEYS WITHOUT THE QUOTES ^_^
module.exports = {
    user_id: "YOUR USER_ID HERE",
    dashboard_id: "YOUR DASHBOARD_ID HERE"
};
