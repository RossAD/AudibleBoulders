// INSERT YOUR OWN KEYS ^_^
module.exports = {
  user_id: "YOUR USER_ID HERE",
  dashboard_id: "YOUR DASHBOARD_ID HERE"
}